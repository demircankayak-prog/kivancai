const { app, BrowserWindow, shell } = require("electron");
const path = require("path");

// Uygulamanin canli adresi. Yayina aldiktan sonra kendi adresinle degistir.
const APP_URL = process.env.KIVANCAI_URL || "https://id-preview--ff727972-53e5-48cd-97c4-db878941ec1e.lovable.app";

function createWindow() {
  const win = new BrowserWindow({
    width: 1280,
    height: 860,
    minWidth: 900,
    minHeight: 600,
    autoHideMenuBar: true,
    backgroundColor: "#0b0d12",
    title: "KivancAI",
    icon: path.join(__dirname, "icon.png"),
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  win.loadURL(APP_URL);

  // Mikrofon / ekran paylasimi izinlerini otomatik ver
  win.webContents.session.setPermissionRequestHandler((_wc, _perm, cb) => cb(true));

  // Disa acilan linkler varsayilan tarayicida acilsin
  win.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: "deny" };
  });

  win.webContents.on("did-fail-load", () => {
    win.loadURL(
      "data:text/html;charset=utf-8," +
        encodeURIComponent(
          "<body style='background:#0b0d12;color:#fff;font-family:sans-serif;display:grid;place-items:center;height:100vh'><div><h2>Baglanti kurulamadi</h2><p>Internet baglantini kontrol edip uygulamayi yeniden ac.</p></div></body>",
        ),
    );
  });
}

app.whenReady().then(createWindow);
app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
app.on("activate", () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
