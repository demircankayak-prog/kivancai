@echo off
title KivancAI - Kurulum ve Calistirma
echo ==========================================
echo   KivancAI Masaustu - Kurulum basliyor
echo ==========================================
where node >nul 2>nul
if errorlevel 1 (
  echo [HATA] Node.js kurulu degil.
  echo Once https://nodejs.org adresinden LTS surumunu kurup bu dosyayi tekrar calistir.
  pause
  exit /b 1
)
call npm install
if errorlevel 1 ( echo [HATA] Kurulum basarisiz. & pause & exit /b 1 )
echo Uygulama aciliyor...
call npm start
pause
