@echo off
title KivancAI - EXE olustur
where node >nul 2>nul
if errorlevel 1 (
  echo [HATA] Node.js kurulu degil. https://nodejs.org adresinden LTS kur.
  pause
  exit /b 1
)
if not exist node_modules ( call npm install )
call npm run build
echo.
echo BITTI! EXE dosyan burada: cikti\KivancAI-win32-x64\KivancAI.exe
pause
